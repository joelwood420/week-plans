# Week 2 Exercises

### 1. Escaping

- What happens when you want to write the words `"<h1>"` inside your
  HTML without making a new element? How can this be solved?
- Can you write the word "Hello" with this technique?

### 2. Comments

- Google (or use Dash for offline classrooms) HTML comment syntax and add comments on your HTML

### 3. Headlines

- "h1-h6": find out about different levels of headlines, when and how often to use which.

### 4. Tables

- HTML has a `<table>` element. Find out how to use it and make a table that works as a
  restaurant menu. List 5 dishes, and for every dish make up and list both a normal price,
  and a discounted price.

### 5. Misc

- Browse the MDN docs (or Dash for offline classrooms) and write out one thing we
  haven't done in class. Prepare to introduce it in a short presentation to your
  class: talk about what it is, and showing an example both as source code
  and in the browser.

## 6. Interactive Website Project

Create a website about your favourite travel destination or shop that demonstrates your understanding of hyperlinks and images.

**Requirements:**
- Use at least three different headlines (`<h1>`, `<h2>`, `<h3>`)
- Use at least three paragraph elements (`<p>`)
- Include at least **three hyperlinks** (`<a>` tags) that link to:
  - One external website (e.g., Wikipedia, official tourism site)
  - One internal anchor link (create a section and link to it)
  - One email link (`mailto:`)
- Include at least **two images** with proper `alt` attributes:
  - One image from an external URL (e.g., using picsum.photos)
  - One image that could be local (use a placeholder URL)
- Use at least one table to display information (e.g., food nutritional values )
- Add at least two HTML comments explaining your code
- Use at least one `div` element to group related content

**Example topics:**
- A shop you like
- Your dream holiday destination
- A city you'd love to visit
- Your favourite type of cuisine

This website can be launched on GitHub Pages (in online classrooms) and should demonstrate proper use of hyperlinks and accessible images. 