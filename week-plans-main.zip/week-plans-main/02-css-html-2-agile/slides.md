---
theme: ../../teacher-materials/take2-theme
class: text-center
highlighter: shiki
lineNumbers: false
info: |
  ## HTML 102
  HTML Structure
drawings:
  persist: false
title: HTML 102
---

# HTML 102

---

```html
<!DOCTYPE html>
<html>
  <head>
    <title>Where am I?</title>
  </head>
  <body>
    <h1>Hello</h1>
  </body>
</html>
```

- (optional) `!DOCTYPE` - let's the browser know it's definitely HTML
- `<head></head>`: metadata about the website
- `<body></body>`: the website's contents

---

## HTML Attributes

- We can make links using the `<a></a>` tag: an anchor.

```html
<a href="https://google.com">
  Click here to go to google.com
</a>
```

- Attributes go in the opening tag
- The format is called key-value
- Here, `href` is the key, and `https://google.com` is the value
- The value uses double quotes, the key does not
- `href` stands for "Hypertext Reference" and tells the link where to go

---

## Images

- We can link images using the `<img/>` tag.

```html
<img src="https://picsum.photos/600/400" alt="A painting"/>
```

- `src` attribute - web address where the image is hosted
- `alt` attribute - provides alternative text for screen readers and when images fail to load
- Always include `alt` text for accessibility - describe what the image shows

---

## HTML Comments

```html
<h1>This is a headline</h1>
<h2>This is also a headline</h2>
<!-- This is a comment, you won't see it on the page -->
<p>This is a paragraph</p>
```

- To give yourself or other engineers a clue about what you were intending

---

## The most-used element

```html
<div>Anything can go in here</div>
```

- `div`: A document division
- When there's no semantic (meaningful) element that suits your purpose,
  or when you just want to group things together, use a `div`

---

## Putting It All Together

Here's a complete example using everything we've learned:

```html
<!DOCTYPE html>
<html>
  <head>
    <title>My Travel Blog</title>
  </head>
  <body>
    <h1>Welcome to My Travel Adventures</h1>
```
---

```html
    <div>
      <h2>Latest Trip: Paris</h2>
      <p>I recently visited the beautiful city of Paris!</p>
      <img src="https://picsum.photos/400/300" 
      alt="Eiffel Tower in Paris during sunset"/>
      <p>Check out my <a href="https://myblog.com/paris-trip">
        full Paris travel guide</a> for more details.
      </p>
    </div>
      </body>
</html>
```

---

This example includes:
- Proper HTML structure with `<!DOCTYPE>`, `<html>`, `<head>`, and `<body>`
- A meaningful page title
- Headings (`<h1>`, `<h2>`) for structure
- Paragraphs (`<p>`) for content
- An image with both `src` and `alt` attributes
- A hyperlink with `href` attribute
- A `div` to group related content
- An HTML comment
