## 🚀 Welcome _back_ to Take2! 🚀

# Week 2

## Learning objectives

- Describe broadly how people work together on software
- Differentiate git, GitHub and web hosting
- Identify special characters used in HTML

## Materials

1. (Online classroms only) - ["How to setup a website with GitHub Pages"](https://pages.github.com) 
2. ["What is the World Wide Web?" by Code.org (Video & Interactive Activities)](https://www.youtube.com/watch?v=J8hzJxb0rpc)
3. ["Getting started with the Web" (MDN Web Docs)](https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web)
4. [W3Schools "HTML Semantics" Tutorial (Interactive Code Examples)](https://www.w3schools.com/html/html5_semantic_elements.asp)

## Assignments

See the exercises.md file in this repository for other assignments.

## Your Achievements for this week

### Online Classroom

- [ ] Upload all your reflections
- [ ] Launch a website on github.io

### Offline Classroom

- [ ] Build your first website
- [ ] Learn to use Dash and W3C to help answer questions we haven't covered in class
