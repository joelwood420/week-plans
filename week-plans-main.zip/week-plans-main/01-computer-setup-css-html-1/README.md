## 🚀 Welcome to Take2! 🚀

# Week 1

## Learning objectives

- Install software on your Mac
- Use Slack to communicate with students & staff
- Upload a repository to GitHub
- Use a code editor to create and save files
- Describe the components of a file system (files, folders, paths)
- Apply the fundamentals of touch typing (e.g. the home row)
- Identify HTML tags

## Materials

1. [Khan Academy Computing - "What is a file?" (Short article and quizzes)](https://www.khanacademy.org/computing/computers-and-internet/xcae6f4a7ff015e7d:computers/xcae6f4a7ff015e7d:computer-files/a/files-introduction)
2. [Visual Studio Code Introduction (2-minute video)](https://code.visualstudio.com/docs/introvideos/basics)
3. [Scrimba’s Free HTML Course (First few minutes)](https://scrimba.com/learn-html-and-css-c0p)
4. [W3Schools "HTML Entities" Page (Interactive)](https://www.w3schools.com/html/html_entities.asp)

Always feel free to look up your own resources, ask for more resources, and share resources with other students.

## Links

[Typing test](https://monkeytype.com)

## Assignments

- [ ] Reflection on Tuesday
- [ ] Reflection on Wednesday
- [ ] Reflection on Thursday

## Your Achievements for this week

- [ ] Make a GitHub account
- [ ] Make a Slack account and join our team
- [ ] Post a greeting on Slack: your name and something you like
- [ ] Create a folder structure on your computer
- [ ] Create your first repository
- [ ] Write your first reflections
- [ ] Measure your typing speed
