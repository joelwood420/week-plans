## 🚀 Welcome to Take2! 🚀

# Week 1

## Learning objectives

- Use a code editor to create and save files
- Describe the components of a file system (files, folders, paths)
- Apply the fundamentals of touch typing (e.g. the home row)
- Identify HTML tags
- Use Dash to find information about HTML
- Understand how to use the shared server

## Materials

1. ["What is a file?"](https://www.youtube.com/watch?v=k-EID5_2D9U)
2. [Visual Studio Code Introduction (2-minute video)](https://www.youtube.com/watch?v=B-s71n0dHUk)
3. Introduction to Dash and W3C, read the HTML basics section
4. Practice typing with the warm up extension

Always feel free to ask for more resources, and share resources with other students.

## Assignments

- [ ] Reflection on Tuesday
- [ ] Reflection on Wednesday
- [ ] Reflection on Thursday

## Your Achievements for this week

- [ ] Create a folder structure on your computer
- [ ] Write your first reflections
- [ ] Measure your typing speed
- [ ] Read the HTML basics section in Dash
