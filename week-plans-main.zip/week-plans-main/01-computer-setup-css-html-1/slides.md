---
theme: ../../teacher-materials/take2-theme
class: text-center
highlighter: shiki
lineNumbers: false
info: |
  ## HTML 101
  An introduction to HTML
drawings:
  persist: false
title: HTML 101
---

# HTML 101

---
layout: center
---

# Let's look at a website

Open google.com. How is it made?

<!--
Show a website, e.g. google.com, and ask learners how this website is made.
There's no need to get it right, it's about facilitating a discussion and
building curiosity.-->

---

### Outcomes for this lesson

- Describe HTML syntax
- Identify common HTML tags
- Create a simple HTML document
- Apply nesting to HTML tags

---

## HTML

- HTML is what a browser uses to show the websites you see
- HTML describes what's on the page - text, images, links, etc.

```html
Weather forecast:
<h1>Sunny days ahead</h1>
<p>Or not. You never know with the weather.</p>
```

- Let's open it in a browser

---

# Understanding Angle Tags

## What are angle tags?

```html
<h1>Hello World</h1>
<p>This is a paragraph</p>
```

- The `<` and `>` symbols are called **angle brackets**
- They tell the browser "this is HTML code"
- Everything between `<` and `>` is an HTML tag

---

## Opening and Closing Tags

```html
<h1>Hello World</h1>
```

<v-click>

- **Opening tag**: `<h1>` - tells browser "start a heading here"
- **Content**: `Hello World` - what the user sees
- **Closing tag**: `</h1>` - tells browser "end the heading here"

</v-click>

<v-click>

- The `/` in the closing tag is like saying "stop" or "end"
- Think of it like opening and closing a book

</v-click>

---

## Why do we need both?

```html
<h1>This is a heading</h1>
<p>This is a paragraph</p>
```

<v-click>

- **Opening tag** = "Start here"
- **Closing tag** = "Stop here"
- Without both, the browser doesn't know where to start and stop!

</v-click>

<v-click>

**Example**: If you only had `<h1>This is a heading`, the browser wouldn't know where the heading ends!

</v-click>

---

## Common Beginner Tags

```html
<h1>Biggest heading</h1>
<h2>Second biggest heading</h2>
<p>This is a paragraph of text</p>
<b>This text is bold</b>
<i>This text is italic</i>
```

<v-click>

- `<h1>` to `<h6>` = Headings (h1 is biggest, h6 is smallest)
- `<p>` = Paragraph
- `<b>` = Bold text
- `<i>` = Italic text

</v-click>

---

## What do tags mean?

```html
<h1>Sunny days ahead</h1>
<p>Or not. You never know with the weather.</p>
```

<v-click>

- `<p></p>` = Paragraph
- `<h1></h1>` = First-order headline

</v-click>

<!-- Identify and name the opening (`<h1>`, `<p>`) and closing tags (`</h1>`,
`</p>`).

Ask students what they think h1 and p stand for. Lead them to the correct
answers: h1 stands for "heading level 1" and p stands for "paragraph."

Explain how HTML tags enclose content to give it meaning, forming elements that
provide the structure and semantics of a webpage. -->

---

## Self-Closing Tags

```html
<br />
<img src="photo.jpg" />
<hr />
```

<v-click>

- Some tags don't need content, so they close themselves
- The `/` at the end means "this tag is complete"
- Examples: line breaks, images, horizontal rules

</v-click>

---

## Practice: Fix the Tags

Which of these are correct?

```html
<h1>My First Website</h1>     ✅ Correct
<p>This is a paragraph<p>      ❌ Missing closing tag
<h2>Another heading<h2>        ❌ Missing closing tag
<b>Bold text</b>              ✅ Correct
<i>Italic text<i>             ❌ Missing closing tag
```

<v-click>

**Remember**: Every opening tag needs a matching closing tag!

</v-click>

---

## What can we put inside an HTML tag?

<v-click>

```html
<h2>Animals</h2>
<ul>
  <li>Cat</li>
  <li>Dog</li>
  <li>Rabbit</li>
</ul>
```

</v-click>

<v-click>

- Which elements don't make sense to nest?
- Can you nest a `<b>` element in a `<h1>` element? Does that make sense?
</v-click>

---

## Practice

- Use
  ```html
  <h3></h3>
  <b></b>
  <i></i>
  <u></u>
  <ul></ul>
  ```

---

## Questions

- An element is defined by it's tag and content. What happens when we change an element's content?
- What happens if we don't close a `<h1>` tag?
- Fix this HTML:

```html {*}{lines: true}
<h1 This is a headline</h1>
<h2>This is a headline</h3>
</h1>This is a headline<h1>
<h1/>This is a headline</h1>
```

---
layout: center
---

# Questions?
