# HTML 101 - Practice Exercise

## Your Second HTML Page

Create a simple HTML page about your favorite hobby or interest. This exercise will help you practice using the HTML tags we learned yesterday.

---

## Task: Create a Personal Hobby Page

### What you'll build:
A simple webpage that introduces your favorite hobby, sport or interest.

### Requirements:

1. **Create a new file** called `my-hobby.html`
2. **Use these HTML tags** in your page:
   - `<h1>` - Main title
   - `<h2>` - Section headings (at least 2)
   - `<p>` - Paragraphs (at least 3)
   - `<b>` - Bold text
   - `<i>` - Italic text
   - `<ul>` and `<li>` - A list of items
   - `<strong>` - Important text (research this!)
   - `<em>` - Emphasized text (research this!)
   - `<mark>` - Highlighted text (research this!)

---

## Your Turn!

### Step 1: Choose Your Topic
Pick one of these topics (or choose your own):
- Your favourite sport
- A hobby you enjoy
- Your dream job
- A place you love
- Your favourite food or cuisine

### Step 2: Plan Your Content
Write down:
- Main title (use `<h1>`)
- 2-3 section headings (use `<h2>`)
- 3-4 paragraphs of text
- A list of 3-5 related items
- Some words to make bold and italic
- Important words to use `<strong>` tags
- Words to emphasize with `<em>` tags
- Key terms to highlight with `<mark>` tags

### Step 3: Research New Tags
Before writing your HTML, research these new tags:
- Visit [W3Schools HTML Reference](https://www.w3schools.com/tags/) or [MDN HTML Elements](https://developer.mozilla.org/en-US/docs/Web/HTML/Element)
- Look up: `<strong>`, `<em>`, and `<mark>` tags
- Understand what each one does and when to use them
- Note: `<strong>` and `<em>` are different from `<b>` and `<i>`!

### Step 4: Create Your HTML
1. Open a text editor (VS Code, Notepad, etc.)
2. Create a new file called `my-hobby.html`
3. Write your HTML using all the tags (including the new ones you researched)
4. Save the file

### Step 5: Test Your Page
1. Double-click your HTML file
2. It should open in your web browser
3. Check that all your tags work correctly

### Step 6: Submit to teacher
1. Locate your html page
2. Slack it to your teacher directly


---

## Checklist

Before you're done, make sure you have:

- [ ] Used `<h1>` for your main title
- [ ] Used `<h2>` for at least 2 section headings
- [ ] Used `<p>` for at least 3 paragraphs
- [ ] Used `<b>` to make some text bold
- [ ] Used `<i>` to make some text italic
- [ ] Used `<ul>` and `<li>` to create a list
- [ ] Used `<strong>` for important text
- [ ] Used `<em>` for emphasized text
- [ ] Used `<mark>` for highlighted text
- [ ] All opening tags have matching closing tags
- [ ] Your page opens correctly in a browser

---

## Bonus Challenge

If you finish early, try adding:
- More headings (`<h3>`, `<h4>`)
- A second list
- More formatting with `<b>`, `<i>`, `<strong>`, `<em>`, and `<mark>`
- A `<br />` tag for line breaks
- Research and use `<audio>` for deleted text
- Research and use `<canvas>` for inserted text

---

## Need Help?

- Remember: Every opening tag needs a closing tag
- The `/` in closing tags is important: `<h1>` vs `</h1>`
- Check your spelling of tag names
- Make sure your file ends with `.html`

---

## What You'll Learn

By completing this exercise, you'll:
- ✅ Practice writing HTML tags correctly
- ✅ Understand how opening and closing tags work
- ✅ See how different tags create different visual effects
- ✅ Learn to structure content with headings and paragraphs
- ✅ Get comfortable with basic HTML syntax
- ✅ Learn to research and discover new HTML tags independently
- ✅ Understand the difference between semantic and presentational tags

## Research Resources

- **[W3Schools HTML Reference](https://www.w3schools.com/tags/)** - Great for beginners
- **[MDN HTML Elements](https://developer.mozilla.org/en-US/docs/Web/HTML/Element)** - More detailed documentation
- **[HTML5 Semantic Elements](https://www.w3schools.com/html/html5_semantic_elements.asp)** - Learn about semantic meaning

**Good luck! Remember, practice makes perfect! 🚀** 