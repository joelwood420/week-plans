## 🚀 Welcome to Week 4 of Take2! 🚀

# Week 4

How's your typing going? Feel free to give our [Typing test](https://monkeytype.com)
another shot. Use the Warm Up extension in offline classrooms.

## Learning objectives

- Reinforce our learning from the previous weeks
- Understand the structure and purpose of HTML forms
- Choose appropriate input types for different data
- Implement basic form validation

## Materials

1. [MDN Web Docs - "HTML forms"](https://developer.mozilla.org/en-US/docs/Learn/Forms)
2. [W3Schools "HTML Form Elements" Tutorial](https://www.w3schools.com/html/html_form_elements.asp)
3. Online classrooms only - [Scrimba's HTML Forms Course](https://scrimba.com/learn/htmlcss)
4. [Learn HTML forms in 8 minutes](https://www.youtube.com/watch?v=2O8pkybH6po)
5. [HTML - Forms - W3Schools.com](https://www.youtube.com/watch?v=VLeERv_dR6Q)
6. [Learn HTML forms in 25 minutes](https://www.youtube.com/watch?v=fNcJuPIZ2WE)

## Assignments

See the exercises.md file in this repository.

## Your Achievements for this week

- [ ] Create a basic HTML form
- [ ] Complete your first review
