---
theme: ../take2-slidev-theme
class: text-center
highlighter: shiki
lineNumbers: false
info: |
  ## HTML 103
  Forms
drawings:
  persist: false
title: HTML 103
---

# HTML 103

Forms

---

- How can we make forms on our webpages?

![](./basic-form.png)

---

- We start and end a form with the `<form></form>` tag
- Then we add  `<input/>` to the form to capture data
- `<label></label>` can give our user an idea what the form field is for

```html
<form>
  <label for="username">Username:</label><br/>
  <input type="text" id="username" name="username"><br/><br/>

  <label for="password">Password:</label><br/>
  <input type="password" id="password" name="password"><br/><br/>

  <input type="submit" value="Submit">
</form>
```

---

## Input attributes

- The `<input/>` tag can assume different shapes, depending on its `type` attribute

```html
<input type="text" id="username" name="username">
<input type="password" id="password" name="password">
<input type="submit" value="Submit">
```

- Same tag, different effect

---

## Where does the data go?

```html
<form action="..." method="POST">
</form>
```

- `action="..."`: URL where the form data will be sent.
- `method="POST"`: HTTP method used to send the data (usually post or get).
  We'll stick to POST for now.

- Our webpage is called a "frontend".
- The place where all the form data is stored is called a "backend".

---
layout: center
---

# Questions
