# 3-column preview card component

![Design preview for the 3-column preview card component coding challenge](./design/desktop-preview.jpg)

## The Challenge

Your challenge is to build out this 3-column preview card component and get it looking as close to the design as possible.

You can use any tools you like to help you complete the challenge. So if you've got something you'd like to practice, feel free to give it a go.

### Required Features:
- The layout of the coloured sections changes for:
    - **Mobile:** 1 column
    - **Desktop:** 3 columns
- See hover states for interactive elements. Refer to the active-states design image to see what changes.

## Where to Find Everything

Your task is to build out the project to the designs inside the `/design` folder. You will find both a mobile and a desktop version of the design.

There is also a `style-guide.md` file containing the information you'll need, such as color palette and fonts.

You'll need to use your best judgment for styles such as `font-size`, `padding`, and `margin`.

You will find all the required assets in the `/images` folder. The assets are already optimized.

## Getting Started

- **Sketch or annotate the design:** Before coding, sketch or annotate the design to identify key elements like headings, text, buttons, and layout sections.
- **Plan your HTML structure:** Think about how to group content and which tags to use for each section.
- **Add responsive styles:** Use simple layout techniques like `flexbox` or `grid` to switch between mobile and desktop layouts.
