# Front-end Style Guide

Use the css values here to get the exact colors, fonts and sizing used in the designs.

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 Start by building the mobile design first. Add media queries later to make the 3 column align side-by-side when viewing at larger screen sizes.

## Colors

### Primary

| color name     | CSS value           |
| -------------- | ------------------- |
| Bright orange  | hsl(31, 77%, 52%)   |
| Dark cyan      | hsl(184, 100%, 22%) |
| Very dark cyan | hsl(179, 100%, 13%) |

### Neutral

| color name        | CSS value               | Where to use                  |
| ----------------- | ----------------------- | ----------------------------- |
| Transparent white | hsla(0, 0%, 100%, 0.75) | paragraphs                    |
| Very light gray   | hsl(0, 0%, 95%)         | background, headings, buttons |

## Typography - styling text

### Font

| Font family           | Weights |
| --------------------- | ------- |
| Lexend Deca           | 400     |
| Big Shoulders Display | 700     |