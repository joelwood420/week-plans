# Week 4 Exercises

### Online Classroom

For this week's exercises, please create a repository on your GitHub profile
named `week-4-exercises`.

### Offline Classroom

For this week's exercises, please create a folder named `week-4-exercises`.

For every exercise, create one HTML page, for example: `1.html` for exercise 1.

## 1. Identify and use HTML attributes

1. Find out what the `alt` attribute for `<img>` tags does and demonstrate its
   use.
2. Find out what the `target` attribute for `<a>` tags does and demonstrate at
   least two options.

## 2. Use semantic elements appropriately

1. Read about semantic HTML elements like `<article>`, `<section>`, `<nav>`,
   `<main>`, `<header>`, `<footer>`, e.g. on the MDN docs website

2. Convert a non-semantic HTML layout to a semantic one. Given the following
   non-semantic HTML structure:

   ```html
   <div id="header">
     <h1>Welcome to My Website</h1>
   </div>
   <div id="main-content">
     <p>This is the main content area.</p>
   </div>
   <div id="footer">
     <p>Contact us at info@example.com</p>
   </div>
   ```

   Create an HTML file and rewrite the above HTML using appropriate semantic
   elements instead of `<div>`.

## 3. Basic form

Create a basic form with two input fields using `<form>` and `<input>`

## 4. Input attributes

We have talked about input `type`, but there are more attributes for `<input>`
tags. Try these attributes to see what they can do:

1. The `placeholder` attribute. Use it with at least **three** different input
   types to see its effect.
2. The `readonly` attribute. Use it with at least **two** different input types
   to see its effect.

At the end of this exercise, you should have a HTML page with at least five
`<input>` elements. Be prepared to share one of your findings with the class.

## 5. Input validation

Use Google (Dash in offline classrooms) to find out how to validate form inputs using HTML5 form validation. Specifically find out about validating in a form input:

1. Setting minimum and maximum lengths for an `input` with type `text`
2. Making an `input` a 'required field'

Create a new HTML file and add a text input with a minimum
length of three and maximum length of ten characters. Create a second input
field that is required.

## 6. Focus

Find out and describe what "focus" means in HTML. Find out about the `autofocus`
attribute and demonstrate its use.

## 7. Project

Build a comprehensive user registration form that incorporates a variety of
input types and includes form validation. Do not use Javascript. CSS is
optional, but encouraged.

### RequestBin (Online classroom only)

To capture your users' form submissions, we will use a RequestBin. RequestBin is
a software to capture HTTP requests (like those made from a user's browser when
they submit a form).

Go to [https://requestbin.whapi.cloud](https://requestbin.whapi.cloud) and
"Create a RequestBin" (public, not private). Then use the displayed **Bin URL**
as your `form`'s `action` attribute.

Please add a link to your RequestBin in your created HTML.

### Form data

We want to collect:

- Name
- Date of Birth
- Gender
- Profile Picture

- Email (with validation)
- Phone Number (with validation)
- Address (textarea)

- Preferred Contact Method (options: Email, Phone, Mail)
- Subscribe to Newsletter, yes or no
- Accept Terms and Conditions, yes or no

- Username
- Password

### Notes

- Use `<fieldset>` to group related fields together.
- Add labels for each input to ensure accessibility.
- Ensure that all required fields are marked and validate them accordingly.
- Add a `hidden` input with name `sender` and your Github username (use your first name in offline classrooms) as the
  `value`. Example: `<input type="hidden" name="sender" value="username"/>`.
- Include a submit button to send the form data.
- To make your life easier, _first_ create your full HTML, and only then add your CSS.
