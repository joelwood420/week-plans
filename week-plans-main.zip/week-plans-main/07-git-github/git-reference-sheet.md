### Git Command Essentials — Quick-Reference Table

| Command                                 | Plain-English purpose                                                                                                                | Typical context                              |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------- |
| `git init`                              | **I’m starting a new repository here.** Converts the current folder into a Git repository by creating the hidden `.git` directory.   | First-time setup of any project.             |
| `git clone <URL>`                       | **Copy an existing repository to my computer.** Downloads all commits, branches, and tags.                                           | Getting a remote project locally.            |
| `git status`                            | **What’s going on right now?** Shows changed files, what’s staged (in the *index*), and the current branch.                          | Continuous check while you work.             |
| `git add <file>` / `git add .`          | **Stage changes for the next commit.** Moves edits from the *working directory* to the *staging area* (index).                       | Before every commit.                         |
| `git commit -m "message"`               | **Record a snapshot.** Wraps the staged content into a new commit object (identified by its *SHA — Secure Hash Algorithm checksum*). | After finishing a logical unit of work.      |
| `git log --oneline --graph --decorate`  | **Show the history visually.** One-line digest with branch pointers and merge arrows.                                                | Understanding history or troubleshooting.    |
| `git diff`                              | **Show line-by-line changes.** Compares working directory ↔︎ index or two commits.                                                    | Code reviews, conflict resolution.           |
| `git branch`                            | **List or manage branches.** Add `-a` for all, `-d` to delete, `-M` to rename.                                                       | Navigating or cleaning branches.             |
| `git checkout -b <new-branch>`          | **Create + switch to a branch in one go.**                                                                                           | Starting any new piece of work.              |
| `git switch <branch>`                   | **Change branches** (modern alternative to `checkout` for switching only).                                                           | Moving between tasks.                        |
| `git merge <branch>`                    | **Combine another branch into the current branch.** Creates a merge commit by default.                                               | Finishing a feature branch.                  |
| `git rebase <branch>`                   | **Replay my commits onto another base.** Yields a linear history.                                                                    | Keeping a feature branch up-to-date.         |
| `git stash push -m "msg"`               | **Shelve uncommitted work temporarily.**                                                                                             | Quick context-switches.                      |
| `git pull` (≡`git fetch` + `git merge`) | **Bring remote changes in and merge them.**                                                                                          | Staying current with the remote main branch. |
| `git push`                              | **Send my local commits to the remote.**                                                                                             | Sharing work or closing a feature.           |
| `git remote -v`                         | **Show the remote repository URLs.** Use `add`, `remove`, `rename` to manage.                                                        | Verifying origins or adding upstream repos.  |
| `git fetch --all --prune`               | **Download everything new without changing my files.** `--prune` deletes tracking refs for deleted branches.                         | Regular hygiene before big merges.           |

---

## Vanilla Git “Git Flow” Walk-through

*Focus: creating and finishing a feature branch*

1. **Synchronise your local `main` branch**

   ```bash
   git checkout main
   git pull origin main   # ensure you have the latest code
   ```

2. **Create and switch to a feature branch**

   ```bash
   git checkout -b feature/<concise-name>
   # or: git switch -c feature/<concise-name>
   ```

3. **Code → Stage → Commit cycle**

   ```bash
   # edit files
   git add <file(s)>
   git commit -m "feat: short explanation"
   # repeat as many times as needed
   ```

4. **Publish the branch to the remote once (sets upstream)**

   ```bash
   git push -u origin feature/<concise-name>
   ```

5. **Keep your feature branch current**

   ```bash
   git fetch origin            # get latest main
   git rebase origin/main      # or: git merge origin/main
   # resolve conflicts if any, then:
   git push --force-with-lease # only after a rebase
   ```

6. **Finish the feature**

   ```bash
   git checkout main
   git pull origin main        # just in case
   git merge --no-ff feature/<concise-name>
   git push origin main
   ```

7. **Clean up**

   ```bash
   git branch -d feature/<concise-name>       # local
   git push origin --delete feature/<concise-name>  # remote
   ```

> **Why `--no-ff`?**
> `--no-ff` stands for *no fast-forward*. It forces Git to create a merge commit, preserving the historical context that a feature branch existed.

---

## Common Mistakes & How to Recover — Step-by-Step

### 1. Accidentally committed `node_modules`

```bash
# Remove the folder from the repo but keep it locally
git rm -r --cached node_modules/

# Tell Git to ignore it from now on
echo "node_modules/" >> .gitignore
git add .gitignore
git commit -m "chore: remove node_modules and ignore it"

# If the bad commit is already on the remote
git push --force-with-lease
```

---

### 2. Forgot to create a branch (committed on `main`)

```bash
# Create a new feature branch from the current (wrong) state
git checkout -b feature/right-place
git push -u origin feature/right-place   # share it

# Reset local main back to the remote’s safe state
git checkout main
git reset --hard origin/main
```

---

### 3. Need to change the last commit (files or message)

```bash
# Stage any additional fixes
git add <corrected files>

# Edit the last commit
git commit --amend -m "new message"

# Overwrite the remote copy only if you’ve already pushed
git push --force-with-lease
```

---

### 4. Undo the last commit but keep changes staged

```bash
git reset --soft HEAD~1     # Rewind history, keep all changes staged
```

---

### 5. Discard local changes completely

```bash
# Single file
git restore <file>

# Entire working directory
git restore .
```

---

### 6. Resolve merge-or-rebase conflicts

```bash
# Open conflicted files, edit until happy, then:
git add <resolved files>

# Continue the interrupted operation
git rebase --continue   # or: git merge --continue
```

---

### 7. Restore a file deleted in the last commit

```bash
git checkout HEAD^ -- path/to/file   # Pull the file from the commit’s parent
git add path/to/file
git commit -m "fix: restore accidentally deleted file"
```

---

### 8. Move uncommitted work to a clean branch

```bash
git stash push -m "wip"      # Shelve current changes
git checkout -b feature/new-start
git stash pop                # Re-apply them on the new branch
```

---

### 9. Clean up stale local tracking branches

```bash
git fetch --prune origin     # Drop refs to deleted remote branches
git branch -vv               # Review remaining locals
git branch -d <branch>       # Delete any you no longer need
```

---

### 10. Remote history was force-pushed (your branch diverged)

```bash
git fetch origin
git rebase origin/main       # Replay your commits on top of the new main
# If conflicts arise, resolve as usual and continue the rebase
```