# Week 7 Final Assessment – Git Workflow Challenge  

Welcome to your end-of-module practical!  
You will prove your new **Git** super-powers by completing a small feature or bug-fix on a starter project, managing the entire workflow from **clone → branch → commit → push → Pull Request → merge** using **ONLY the command-line interface (CLI)** on macOS.

---

## 1 . Objectives  
- Demonstrate clean, frequent commits with clear messages.  
- Use a **feature branch** (Git Flow convention) instead of working on `main`.  
- Push to a remote (**GitHub** for online / **Gitea** for offline).  
- Open a **Pull Request (PR)**, respond to review comments, and merge.  
- Resolve any merge conflicts that arise.  

---

## 2 . Setup  

| Mode               | Remote location                                    | First step                                                                                                                  |
| ------------------ | -------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| **Online stream**  | GitHub classroom org → `starter-webapp` repository | **Fork** the repo to *your* account, then `git clone` your fork                                                             |
| **Offline stream** | Internal Gitea server → `/course/starter-webapp`   | Instructor has **created a personal repo for you** – clone with `git clone http://<gitea>/your-username/starter-webapp.git` |

> **Tip**: run `git config --global user.name` and `user.email` once more to ensure commits are attributed correctly.

---

## 3 . Your Task  
Add the missing **“About” page** feature:

1. Create a **new branch** from the latest `develop` (or `main` if `develop` doesn’t exist):  
   ```bash
   git checkout develop          # or main  
   git pull                       # always start up-to-date  
   git checkout -b feature/about-page
    ```

2. Open `about.html` *(already scaffolded but empty)*, add meaningful content + link it into `index.html`.
3. Commit regularly (min 4 commits) as you:

   ```bash
   git add .          # or specific files  
   git commit -m "Add header structure to About page"
   ```
4. Push your branch to the remote:

   ```bash
   git push -u origin feature/about-page
   ```
5. **Open a Pull Request** targeting `develop` (online) or `main` (offline repo without develop).

   * Fill title: `feat: About page`.
   * In the description list **what** you built and **why**.
6. Review checklist:

   * ✅ At least 4 descriptive commits.
   * ✅ No unrelated changes (single-purpose commits).
   * ✅ Branch passes `index.html` link checker *(run `npm test` if provided)*.
7. Respond to reviewer comments (peer or instructor).
8. When approved, **merge** (use the default merge commit). Delete the remote branch.
9. Pull down the updated `main` / `develop` locally: `git checkout develop && git pull`.

---

## 4 . Submission

| Stream      | Submit                                                   |
| ----------- | -------------------------------------------------------- |
| **Online**  | Paste your **PR URL** in the LMS or Slack thread.        |
| **Offline** | Paste your **Gitea PR number** (e.g. `#12`) or repo URL. |

**Deadline**: end of Day 4 session.

---

## 5 . Grading Rubric (100 pts)

| Area                                                | Points |
| --------------------------------------------------- | ------ |
| Correct workflow (branch → PR → merge)              | 40     |
| Commit frequency & message clarity                  | 30     |
| PR description & review responses                   | 15     |
| Clean repo (no `.DS_Store`, deleted feature branch) | 10     |
| Conflict handled gracefully (if any)                | 5      |

*A fail-safe branch with a single “big-bang” commit will not pass.*

---

## 6 . Quick Reference

| Action          | Command                                      |
| --------------- | -------------------------------------------- |
| Check status    | `git status`                                 |
| Stage changes   | `git add <file>`                             |
| Commit          | `git commit -m "message"`                    |
| See history     | `git log --oneline --graph`                  |
| Switch branch   | `git checkout <name>` or `git switch <name>` |
| Pull latest     | `git pull`                                   |
| Push new branch | `git push -u origin <branch>`                |

---

## 7 . Troubleshooting

* **Push rejected?** → `git pull --rebase` (resolve, then push).
* **On wrong branch?** → `git checkout -b correct-branch` + cherry-pick or reset.
* **Merge conflict?**

  1. Open conflicted file, look for `<<<<<<<`, edit to final version.
  2. `git add <file>` → `git commit`.
* **Forgot a file?** → `git add` then `git commit --amend` *before* pushing.

---

Happy committing – show us a professional Git history!