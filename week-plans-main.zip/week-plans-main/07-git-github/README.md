## 🚀 Welcome to Week 7 of Take2! 🚀

# Week 7

## Learning objectives

- Install, configure, and use Git entirely from the macOS command-line.
- Create small, descriptive commits and inspect project history.
- Clone, pull, push, and resolve merge conflicts with a remote.
- Apply feature-branch workflow using a simplified Git Flow model.
- Open pull requests and perform basic peer code reviews.
- Maintain a clean, readable commit log that meets team standards.

## Materials

[Git Basics](https://docs.github.com/en/get-started/git-basics)
[Atlassian Git Flow tutorial](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow)

## Assignments

- [ ] Complete the Git Flow assessment explained in `git-flow-assessment.md`

## Your Achievements for this week

- [ ] Master the Git Flow workflow.
- [ ] Demonstrate the ability to contribute to a project using Git.