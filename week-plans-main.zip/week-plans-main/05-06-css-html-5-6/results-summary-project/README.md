# Results Summary Component

![Design preview for the Results Summary Component coding challenge](./design/desktop-preview.jpg)

## The Challenge

Your challenge is to build out this results summary component and get it looking as close to the design as possible.

You can use any tools you like to help you complete the challenge. So if you've got something you'd like to practice, feel free to give it a go.

### Required Features:
- Create a responsive results summary card that works on both mobile and desktop
- Display the overall score in a circular progress indicator
- Show individual category scores with appropriate icons and colors
- Implement hover states for interactive elements

### Extension Features (Advanced - requires Javascript)
- Use Javascript and the provided data.json file to populate the individual category scores dynamically
- Calculate the average score from each category and display it in the summary card
- Dynamically change the message based on the average score:
  - Above 90: "Excellent"
  - 70-90: "Good" 
  - 50-70: "Average"
  - Below 30: "Poor"

## Where to Find Everything

Your task is to build out the project to the designs inside the `/design` folder. You will find both a mobile and a desktop version of the design.

There is also a `style-guide.md` file containing the information you'll need, such as color palette and fonts.

You'll need to use your best judgment for styles such as `font-size`, `padding`, and `margin`.

You will find all the required assets in the `/assets` folder. The assets are already optimized.

The `data.json` file contains the scores and categories that you'll need to display.

## Getting Started

- **Sketch or annotate the design:** Before coding, sketch or annotate the design to identify key elements like the score display, category cards, and layout sections.
- **Plan your HTML structure:** Think about how to organize the content and which semantic HTML elements to use.
- **Add responsive styles:** Use CSS to ensure the component looks good on both mobile and desktop views.
- **Implement the score display:** Create a circular progress indicator for the overall score.
- **Style the category cards:** Use appropriate colors and icons for each category.