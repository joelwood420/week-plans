# Front-end Style Guide

Use the css values here to get the exact colors, fonts and sizing used in the designs.

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 Start by building the mobile design first. Add media queries later to adjust the layout for larger screen sizes.

## Colors

### Primary

| color name     | CSS value           |
| -------------- | ------------------- |
| Light red      | hsl(0, 100%, 67%)   |
| Orangey yellow | hsl(39, 100%, 56%)  |
| Green teal     | hsl(166, 100%, 37%) |
| Cobalt blue    | hsl(234, 85%, 45%)  |

### Neutral

| color name     | CSS value           | Where to use |
| -------------- | ------------------- | ------------ |
| White          | hsl(0, 0%, 100%)    | background   |
| Light blue     | hsl(221, 100%, 96%) | background   |
| Light lavender | hsl(241, 100%, 89%) | background   |
| Dark gray blue | hsl(224, 30%, 27%)  | text         |

## Typography - styling text

### Font

| Font family    | Weights       |
| -------------- | ------------- |
| Hanken Grotesk | 500, 700, 800 |

## Gradients

| From                   | To                     | Where to use |
| ---------------------- | ---------------------- | ------------ |
| hsl(252, 100%, 67%)    | hsl(241, 81%, 54%)     | background   |
| hsla(256, 72%, 46%, 1) | hsla(241, 72%, 46%, 0) | circle       |

### Notes

Use transparency to get the color variations necessary to match the design. Hint: look into using `hsla()`.

## Typography

### Body Copy

- Font size (paragraphs): 18px