# Front-end Style Guide

Use the css values here to get the exact colors, fonts and sizing used in the designs.

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 Start by building the mobile design first. Add media queries later to adjust the layout for larger screen sizes.

## Colors

### Primary

| color name    | CSS value          |
| ------------- | ------------------ |
| Cyan          | hsl(179, 62%, 43%) |
| Bright yellow | hsl(71, 73%, 48%)  |
| Light gray    | hsl(204, 43%, 93%) |

### Neutral

| color name   | CSS value          | Where to use |
| ------------ | ------------------ | ------------ |
| Grayish blue | hsl(218, 22%, 67%) | text         |
| Light gray   | hsl(204, 43%, 93%) | background   |
| White        | hsl(0, 0%, 100%)   | background   |

## Typography - styling text

### Font

| Font family | Weights  |
| ----------- | -------- |
| Karla       | 400, 700 |
