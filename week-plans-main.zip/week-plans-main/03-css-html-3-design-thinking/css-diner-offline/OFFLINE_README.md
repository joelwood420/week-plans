# CSS Diner - Offline Version

This is an offline version of CSS Diner, a fun game to learn and practice CSS selectors.

## How to Use Offline

1. Simply open the `index.html` file in any modern web browser:

   - Double-click the `index.html` file
   - Or drag and drop the `index.html` file into your browser
   - Or right-click and select "Open with" your preferred browser

## Features

- All 32 levels of CSS selector challenges
- Complete offline functionality - no internet connection required
- Local fonts and images
- Progress is saved in your browser's local storage

## File Structure

- `index.html` - Main game file
- `css/` - Stylesheets
- `js/` - JavaScript files
- `images/` - Game images
- `fonts/` - Local font files (Exo 2 and Satisfy)

## Original Project

CSS Diner was created by [@flukeout](http://www.twitter.com/flukeout). The original online version is available at [flukeout.github.io](http://flukeout.github.io/) or [cssdiner.com](http://cssdiner.com/).

Enjoy learning CSS selectors offline!
