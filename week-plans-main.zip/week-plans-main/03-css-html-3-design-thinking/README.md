## 🚀 Welcome to Week 3 of Take2! 🚀

# Week 3

## Learning objectives

- Understand the basics of CSS syntax and selectors
- Apply styles to text and elements
- Describe and use the CSS box model
- Create layouts using Flexbox

- Understand the CSS cascade
- Combine multiple CSS selectors in one rule
- Understand the role of pseudo-classes in the daily use of CSS
- Identify common pseudo-classes
- Given two CSS rules, determine which one has precedence
- Reason about document font sizes and units

## Materials

1. [MDN Web Docs - "CSS Basics"](https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/CSS_basics)
2. [Learn CSS in 20 Minutes](https://www.youtube.com/watch?v=1PnVor36_40)
3. [Learn CSS in 1 hour](https://www.youtube.com/watch?v=wRNinF7YQqQ)
4. [CSS HEX Color](https://www.youtube.com/watch?v=P0LRSXh5ncQ)
5. [CSS Color Notation](https://www.youtube.com/watch?v=Ddc-IIrIot0)
6. [Learn CSS flexbox in 10 minutes!](https://www.youtube.com/watch?v=GteJWhCikCk)
7. [CSS Tricks - "A Complete Guide to Flexbox"](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
8. Online classroom -[CSS Diner - practice tool](https://flukeout.github.io)
9. Offline classroom - Pull the CSS Diner folder from the shared server. Read the OFFLINE-README.md to get it running, this is a great tool for practicing how CSS selectors work.

## Assignments

See the exercises.md file in this repository.

## Your Achievements for this week

- [ ] A presentation on a CSS selector feature
- [ ] A website styled using CSS
