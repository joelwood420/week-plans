# Blog Preview Card

![Design preview for the Blog Preview Card coding challenge](./design/desktop-design.jpg)

## The Challenge

Your challenge is to build out this blog preview card component and get it looking as close to the design as possible.

You can use any tools you like to help you complete the challenge. So if you've got something you'd like to practice, feel free to give it a go.

### Required Features:
- Create a responsive blog preview card that works on both mobile and desktop
- Implement hover states for interactive elements
- Display the author's avatar and information
- Show the article's featured image
- Include proper spacing and typography as per the design

## Where to Find Everything

Your task is to build out the project to the designs inside the `/design` folder. You will find both a mobile and a desktop version of the design.

There is also a `style-guide.md` file containing the information you'll need, such as color palette and fonts.

You'll need to use your best judgment for styles such as `font-size`, `padding`, and `margin`.

You will find all the required assets in the `/assets` folder. The assets are already optimized.

## Getting Started

- **Sketch or annotate the design:** Before coding, sketch or annotate the design to identify key elements like headings, text, images, and layout sections.
- **Plan your HTML structure:** Think about how to organize the card content and which semantic HTML elements to use.
- **Add responsive styles:** Use CSS to ensure the card looks good on both mobile and desktop views.
- **Implement hover effects:** Add smooth transitions for interactive elements.