# Front-end Style Guide

Use the css values here to get the exact colors, fonts and sizing used in the designs.

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 Start by building the mobile design first. Add media queries later to adjust the layout for larger screen sizes.

## Colors

### Primary

| color name | CSS value         |
| ---------- | ----------------- |
| Yellow     | hsl(47, 88%, 53%) |
| Black      | hsl(0, 0%, 7%)    |
| White      | hsl(0, 0%, 100%)  |

### Neutral

| color name | CSS value       | Where to use  |
| ---------- | --------------- | ------------- |
| Grey       | hsl(0, 0%, 50%) | text, borders |
| Light grey | hsl(0, 0%, 95%) | background    |

## Typography - styling text

### Font

| Font family | Weights  |
| ----------- | -------- |
| Figtree     | 500, 800 |
